import React from "react";

export default function About() {
  return (
    <div
      className="container-fluid p-5"
      style={{
        backgroundColor: "#f8f9fa",
        borderRadius: "8px",
        boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
      }}
    >
      <h1 className="mb-4" style={{ color: "#343a40", fontWeight: "bold" }}>
        .
      </h1>
      <h2 className="mb-4" style={{ color: "#6c757d" }}>
        .
      </h2>
      <p>...</p>
    </div>
  );
}
